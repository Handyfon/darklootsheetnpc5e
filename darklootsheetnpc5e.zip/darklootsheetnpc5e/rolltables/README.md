# Loot Sheet NPC 5E Rollable Tables

These rollable tables can be imported into your world for use with Loot Sheet NPC 5E

### How to import Rollable Tables

- Go to the Rollable Tables tab
- Create a new Rollable Table
- Right-click the new Rollable Table in the right sidebar and choose Import Data
- Browse to your Data\modules\lootsheetnpc5e\rolltables folder and choose the json file you want to build the Rollable Table based on
- Click Import

### Credits

These tables contain only items from the DND5E compendium included with the DND5E game system for Foundry VTT.

Special thanks to Leric (Leric#8703) for putting them together.